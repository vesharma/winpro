
#include <sensorsapi.h>

#include <initguid.h>
#include <locationapi.h>
